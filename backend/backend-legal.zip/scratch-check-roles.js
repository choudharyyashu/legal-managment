const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const roles = await prisma.role.findMany();
  console.log('ROLES:', roles.map(r => r.id));
}

main().finally(() => prisma.$disconnect());

